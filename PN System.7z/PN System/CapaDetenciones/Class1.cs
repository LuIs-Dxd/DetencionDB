﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Agregamos lo siguiente para utilizar SQL
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using CapaDatos;

namespace CapaDetenciones
{
    public class Class1
    {
    }
}
